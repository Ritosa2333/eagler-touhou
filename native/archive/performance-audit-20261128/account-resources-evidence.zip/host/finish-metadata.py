from pathlib import Path
import hashlib, json, subprocess, zipfile

p=Path(__file__).resolve().parent
repo=Path('C:/Users/Ritosa/AppData/Local/Packages/OpenAI.Codex_2p2nqsd0c76g0/LocalCache/Local/eagler-account-api-routing')
native=repo/'native'
archive=native/'archive/performance-audit-20261128'
out=Path('D:/workspace/eagler/artifacts/native-launcher-85941f0d56/hover-detail-perf')
read=lambda f:json.loads(f.read_text(encoding='utf-8'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def write(f,r): f.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
file=native/'docs/evidence/windows/ui-handoff.json'
r=read(file)
previous=json.loads(subprocess.check_output(['git','show','73769c99d8311fbd37596e35d23bc0beb42b555e:native/docs/evidence/windows/ui-handoff.json'],cwd=repo))
r['inheritedVerification']={'scope':'Prior unchanged Dart/UI checks; not rerun for this native-only patch',
    'packageSha256':previous['packageSha256'],'checks':previous['verification']}
r['inheritedNativeVerification']['scope']='Historical native lifetime checks before the capture frame-pool fix. Current native tests are recorded in account-resources-summary.json.'
r['inheritedNativeVerification']['packageSha256']=previous['packageSha256']
r['inheritedNativeVerification']['pluginSha256']=read(p/'trial-handle-types/input.json')['pluginSha256']
for item in ['CookieManager successful lookup temporary WebView cleanup and generic handle/process lifetime',
    'One public guest form load did not show expected fields; cause unconfirmed']:
    if item not in r['pending']: r['pending'].append(item)
write(file,r)
evidence=archive/'account-resources-evidence.zip'
with zipfile.ZipFile(evidence,'a',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    name='host/finish-metadata.py'
    assert name not in z.namelist()
    z.write(Path(__file__),name)
summaryFile=archive/'account-resources-summary.json'
summary=read(summaryFile)
summary['evidence']['files'][name]=sha(Path(__file__))
summary['evidence'].update(sha256=sha(evidence),entries=len(summary['evidence']['files']))
with zipfile.ZipFile(evidence) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in summary['evidence']['files'].items())
write(summaryFile,summary)
receiptFile=archive/'receipt.json'
receipt=read(receiptFile)
receipt['currentBuild']=read(out/'delivery.json')
receipt['packageChangedFiles']=['flutter_inappwebview_windows_plugin.dll']
for name in ['account-resources-summary.json','account-resources-evidence.zip']:
    receipt['files'][name]=sha(archive/name)
assert all(sha(archive/name)==digest for name,digest in receipt['files'].items())
write(receiptFile,receipt)
print('Current and historical native verification scopes corrected; all receipt hashes verified')
