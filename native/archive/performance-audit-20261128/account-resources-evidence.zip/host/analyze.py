from pathlib import Path
import json, statistics

p=Path(__file__).resolve().parent
mib=1024*1024
def load(name):
    folder=p/('trial-'+name)
    rows=[json.loads(line) for line in (folder/'samples.jsonl').read_text().splitlines()]
    result=json.loads((folder/'process-result.json').read_text())
    return folder,rows,result
def metrics(rows,pid):
    rows=[r for r in rows if any(x['pid']==pid for x in r['processes'])]
    def median(f): return round(statistics.median(f(r) for r in rows),3)
    return {'samples':len(rows),
      'parentPrivateMiB':median(lambda r:next(x['privateCommit'] for x in r['processes'] if x['pid']==pid)/mib),
      'childrenPrivateMiB':median(lambda r:sum(x['privateCommit'] for x in r['processes'] if x['pid']!=pid)/mib),
      'groupPrivateMiB':median(lambda r:sum(x['privateCommit'] for x in r['processes'])/mib),
      'parentHandles':median(lambda r:next(x['handles'] for x in r['processes'] if x['pid']==pid)),
      'descendants':median(lambda r:len(r['processes'])-1)}
control,cr,cp=load('control')
repeat,rr,rp=load('repeated')
assert cp['testReport']['passed'] and rp['testReport']['passed']
assert not cp['forced'] and not rp['forced'] and cp['exitCode']==rp['exitCode']==0
closed=[r for r in rp['testReport']['records'] if r['phase']=='closed']
assert len(closed)==16 and all(r['nativeViewRemoved'] for r in closed)
cycles=[]
for cycle in range(16):
    rows=[r for r in rr if r['phase'].get('phase')=='closed' and r['phase'].get('cycle')==cycle]
    assert rows,cycle
    cycles.append({'cycle':cycle+1,**metrics(rows[-2:],rp['pid'])})
idle=lambda rows:[r for r in rows if r['phase'].get('phase')=='idle'][-10:]
report={'scope':'Same Release integration AOT, production main imports and canonical DLLs; own nonactivating Windows host, public guest login. Private commit is not physical resident memory. No forced GC or heap trimming. Parent absolute values include the test runtime; no ordinary-app or foreground-FPS claim.',
    'controlIdle':metrics(idle(cr),cp['pid']),
    'repeatedBaseline':metrics([r for r in rr if r['phase'].get('phase')=='baseline'],rp['pid']),
    'perCycleClosed':cycles,'repeatedIdle':metrics(idle(rr),rp['pid']),
    'knownDescendants':rp['knownDescendants'],'survivorsAfterExit':rp['survivorsAfterEightSeconds'],
    'bothProcessesExitedNormally':True}
(p/'measurement.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
