from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, statistics, zipfile

p = Path(__file__).resolve().parent
native = Path('C:/Users/Ritosa/AppData/Local/Packages/OpenAI.Codex_2p2nqsd0c76g0/LocalCache/Local/eagler-account-api-routing/native')
stage = Path('D:/workspace/eagler/artifacts/.native-room-client-win')
runtime = p.parent/'shutdown-guard/production'
out = Path('D:/workspace/eagler/artifacts/native-launcher-85941f0d56')
archive = native/'archive/performance-audit-20261128'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
read = lambda f: json.loads(f.read_text(encoding='utf-8'))
def write(f, value):
    f.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
now = datetime.now(timezone.utc).isoformat()
names = ['control','repeated','handle-types','framepool','framepool-repeat','canonical']
trials = {name:read(p/('trial-'+name)/'process-result.json') for name in names}
inputs = {name:read(p/('trial-'+name)/'input.json') for name in names}
assert len({r['testAotSha256'] for r in inputs.values()})==1
assert len({r['targetSha256'] for r in inputs.values()})==1
assert all(r['exitCode']==0 and not r['forced'] and not r['survivorsAfterEightSeconds'] for r in trials.values())
assert all(r['testReport']['passed'] for name,r in trials.items() if name!='framepool')
assert trials['framepool']['testReport']['passed'] is False
for name in ['handle-types','framepool-repeat','canonical']:
    records = trials[name]['testReport']['records']
    assert len([r for r in records if r['phase']=='closed'])==16
    assert len([r for r in records if r['phase']=='loaded' and r['document']['bootReady']])==16
    trace = [json.loads(line) for line in (p/('trial-'+name)/'events.jsonl').read_text().splitlines()]
    assert any(r['event']=='engine_destroyed' for r in trace)
    assert all(r.get('foregroundPid')!=trials[name]['pid'] for r in trace)

def handles(name):
    directory=p/('trial-'+name)
    baseline=read(directory/'handles-baseline--1.json')['result']['types']
    points=[]
    for file in directory.glob('handles-*.json'):
        item=read(file)
        assert item['exitCode']==0 and item['result']['freeResult']==0 and item['result']['walkResult']==259
        phase=item['phase']
        types=item['result']['types']
        points.append({'phase':phase['phase'],'cycle':phase['cycle'],
            'compositionDelta':types.get('DxgkCompositionObject',0)-baseline.get('DxgkCompositionObject',0),
            'sharedResourceDelta':types.get('DxgkSharedResource',0)-baseline.get('DxgkSharedResource',0),
            'total':item['result']['total']})
    return sorted(points,key=lambda r:(r['cycle'],r['phase']))
handleResults={name:handles(name) for name in ['handle-types','framepool-repeat','canonical']}
beforeIdle=next(r for r in handleResults['handle-types'] if r['phase']=='idle')
assert (beforeIdle['compositionDelta'],beforeIdle['sharedResourceDelta'])==(32,16)
assert all(r['compositionDelta']==2*(r['cycle']+1) and r['sharedResourceDelta']==r['cycle']+1
    for r in handleResults['handle-types'] if r['phase']=='closed')
assert all(r['compositionDelta']==r['sharedResourceDelta']==0
    for name in ['framepool-repeat','canonical'] for r in handleResults[name])

memory={}
for name in ['handle-types','canonical']:
    rows=[json.loads(line) for line in (p/('trial-'+name)/'samples.jsonl').read_text().splitlines()]
    idle=[r for r in rows if r['phase'].get('phase')=='idle'][-10:]
    pid=trials[name]['pid']
    parent=lambda r:next(x for x in r['processes'] if x['pid']==pid)
    memory[name]={'samples':len(idle),
        'parentPrivateCommitMiB':round(statistics.median(parent(r)['privateCommit']/1024**2 for r in idle),3),
        'parentHandles':statistics.median(parent(r)['handles'] for r in idle),
        'liveDescendants':statistics.median(len(r['processes'])-1 for r in idle)}
    assert memory[name]['liveDescendants']==0
production=read(p/'production-results.json')
assert len(production)==2 and [(x['firstFrames'],x['enginesDestroyed']) for x in production]==[(1,1),(2,2)]
assert all(x['exitCode']==0 and x['wait']==0 and not x['forced'] and x['foregroundAlwaysOutsideTest'] for x in production)
plugin=runtime/'flutter_inappwebview_windows_plugin.dll'
assert inputs['canonical']['pluginSha256']==sha(plugin)
assert all(r['pluginSha256']==sha(plugin) for r in production)
assert all(r['aotSha256']==sha(runtime/'data/app.so') for r in production)
assert 'Generating done' in (p/'canonical-configure.log').read_text()
assert 'texture_bridge.cc' in (p/'canonical-build.log').read_text(encoding='utf-8-sig')
assert (p/'framepool/source/custom_platform_view/texture_bridge.cc').read_text()==(stage/'build/windows/x64/webview_renderer_adapter/custom_platform_view/texture_bridge.cc').read_text()
old=read(out/'hover-detail-perf/delivery.json')
hashes={name:sha(native/name) for name in old['sourceSha256']}
assert all(sha(stage/name)==digest for name,digest in hashes.items())
assert [name for name in hashes if hashes[name]!=old['sourceSha256'][name]]==[
    name for name in hashes if name in ['windows/webview_renderer_adapter.cmake','windows/webview-renderer-adapter.patch']]

target=out/old['package']
assert sha(target)==old['sha256']
candidate=p/'windows-next.zip'
previous=out/'touhouonline-windows-preview.previous.zip'
assert not candidate.exists()
if previous.exists(): os.replace(previous,candidate)
changed=[]
files={}
with zipfile.ZipFile(target) as before,zipfile.ZipFile(candidate,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as after:
    for item in before.infolist():
        assert not item.is_dir()
        data=(runtime/item.filename).read_bytes()
        if data!=before.read(item.filename): changed.append(item.filename)
        after.writestr(item,data)
        files[item.filename]=hashlib.sha256(data).hexdigest()
assert changed==['flutter_inappwebview_windows_plugin.dll'],changed
with zipfile.ZipFile(candidate) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(name)).hexdigest()==digest for name,digest in files.items())
os.replace(target,previous)
os.replace(candidate,target)
original=stage/'build/windows/x64/runner/Release'
originalHashes=read(p.parent/'shutdown-guard/original-preview-hashes.json')
assert all(sha(original/name)==digest for name,digest in originalHashes.items())
write(p/'package.json',{'oldPackageSha256':old['sha256'],'sha256':sha(target),'bytes':target.stat().st_size,
    'files':len(files),'changedFiles':changed,'pluginSha256':sha(plugin),'aotSha256':sha(runtime/'data/app.so'),
    'originalPreviewFilesUnchanged':len(originalHashes)})

evidence=archive/'account-resources-evidence.zip'
assert not evidence.exists()
evidenceFiles={}
with zipfile.ZipFile(evidence,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    selected=[(p/name,'host/'+name) for name in ['account_memory_probe.dart','run.py','run-memory-only.py','analyze.py','measurement.json',
        'prepare.py','prepare-framepool.py','handle-types.cpp','build-handles.cmd','verify-production.py','finalize.py',
        'canonical-configure.log','canonical-build.log','production-results.json','package.json',
        'startup-high-events.jsonl','startup-high-runtime.log','engines-default-events.jsonl','engines-default-runtime.log']]
    selected += [(p/'framepool'/name,'candidate/'+name) for name in ['inputs.json','compile.rsp','link.rsp','build.cmd','build.log','source/custom_platform_view/texture_bridge.cc']]
    selected += [(file,name+'/'+file.relative_to(p/('trial-'+name)).as_posix()) for name in names
        for file in (p/('trial-'+name)).rglob('*') if file.is_file()]
    for file,name in selected:
        z.write(file,name)
        evidenceFiles[name]=sha(file)
with zipfile.ZipFile(evidence) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(name)).hexdigest()==digest for name,digest in evidenceFiles.items())
summary={'checkedAtUtc':now,'scope':'Windows Release integration using the same production-main-importing test AOT before and after a native capture-frame-pool fix; owned nonactivating hosts; public guest account; native Back and Close at 390 px',
    'input':inputs,'handles':handleResults,'idleMemory':memory,'production':production,'package':read(p/'package.json'),
    'verification':{'liveFormsPerCompleteTrial':16,'backPerCompleteTrial':8,'closePerCompleteTrial':8,'idleSeconds':15,
        'allCompleteTrialsRestoreSameGameHeading':True,'allHostsNormalExit':True,'allObservedDescendantsExited':True,
        'sameTestAotAcrossAllTrials':True,'sameOrdinaryDartAot':True,'noForcedGc':True,'noHeapTrimming':True,
        'originalPreviewFilesUnchanged':len(originalHashes),'lockedPatchFiles':7},
    'interruptedTrial':{'trial':'framepool','completedVisits':15,'reason':'Login path present but expected form fields absent on visit 16; cause unconfirmed; retained as a failed trial, not counted as full regression'},
    'remaining':['CookieManager successful lookup skips temporary WebView cleanup; source finding awaiting isolated non-session-cookie validation',
        'Other generic handle counts and WebView2 helper-process churn need separate lifetime measurement',
        'Foreground hover/detail frame pacing, GPU residency/power and other devices are separate acceptance scopes',
        'Credentialed login/logout and real upload/crop remain outside public guest trials'],
    'evidence':{'file':evidence.name,'sha256':sha(evidence),'entries':len(evidenceFiles),'files':evidenceFiles},
    'references':['https://learn.microsoft.com/en-us/uwp/api/windows.graphics.capture.direct3d11captureframepool.close',
        'https://github.com/niiightmarexd/windows-capture/blob/main/src/graphics_capture_api.rs',
        'https://learn.microsoft.com/en-us/windows/win32/api/processsnapshot/nf-processsnapshot-psscapturesnapshot']}
write(archive/'account-resources-summary.json',summary)
checks=summary['verification']
record={**old,'checkedAtUtc':now,'sha256':sha(target),'bytes':target.stat().st_size,'sourceSha256':hashes,
    'scope':'Ordinary main.dart Windows Release | capture frame-pool cleanup | only Windows WebView DLL changed; ordinary Dart AOT and UI unchanged | no deployment',
    'checks':checks,'inheritedChecks':{'scope':'Previous unchanged Dart/UI verification, not rerun for this native-only fix','checks':old['checks']}}
write(out/'hover-detail-perf/delivery.json',record)
manifestFile=native/'docs/evidence/current/manifest.json'
manifest=read(manifestFile)
assert all(sha(native/c['file'])==c['sha256'] for c in manifest['captures'])
manifest['productionSourceMatchesWindowsPackage'].update(checkedAtUtc=now,sha256=record['sha256'],source=hashes,scope=record['scope'])
write(manifestFile,manifest)
handoffFile=native/'docs/evidence/windows/ui-handoff.json'
handoff=read(handoffFile)
handoff.update(checkedAtUtc=now,builtAtUtc=now,packageSha256=record['sha256'],source=hashes,scope=record['scope'],
    changes='关闭 Windows 网页捕获帧池并释放末帧纹理；原生插件重新编译。普通 Dart AOT、页面布局和原预览文件不变。',
    verification=checks,inheritedVerification=record['inheritedChecks'])
write(handoffFile,handoff)
receiptFile=archive/'receipt.json'
receipt=read(receiptFile)
receipt['files'].update({name:sha(archive/name) for name in ['account-resources-summary.json','account-resources-evidence.zip']})
receipt['accountResources']={'summary':'account-resources-summary.json','currentPackageSha256':record['sha256'],'pluginSha256':sha(plugin)}
receipt['windowsPackageSha256']=record['sha256']
write(receiptFile,receipt)
print(json.dumps({'package':record['sha256'],'beforeIdle':memory['handle-types'],'afterIdle':memory['canonical'],'evidenceEntries':len(evidenceFiles)},ensure_ascii=False))
