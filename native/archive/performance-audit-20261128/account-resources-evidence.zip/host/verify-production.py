from pathlib import Path
import ctypes, hashlib, json, os, subprocess, time

p = Path(__file__).resolve().parent
runtime = p.parent / 'shutdown-guard/production'
folder = p / 'ordinary-preview'
folder.mkdir(exist_ok=False)
for file in runtime.rglob('*'):
    if file.is_file():
        destination = folder / file.relative_to(runtime)
        destination.parent.mkdir(parents=True, exist_ok=True)
        os.link(file, destination)
for name in ['gpu-audit.exe', 'cycle-audit.exe']:
    os.link(p.parent / 'graphics-owned/canonical-preview' / name, folder / name)
kernel = ctypes.WinDLL('kernel32', use_last_error=True)
kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
results = []
for name, mode, args in [('startup-high', 'high', []), ('engines-default', 'default', ['https://touhouonline.com/login.html?lang=zh-CN'])]:
    events = p / (name + '-events.jsonl')
    exe = folder / ('cycle-audit.exe' if args else 'gpu-audit.exe')
    with (p / (name + '-runtime.log')).open('wb') as log:
        child = subprocess.Popen([str(exe)] + args, cwd=folder, env=dict(os.environ,
            TOUHOU_GPU_PREFERENCE=mode, TOUHOU_PROBE_LOG=str(events)), stdout=log,
            stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        print(json.dumps({'trial': name, 'pid': child.pid}), flush=True)
        start = time.perf_counter()
        wait = kernel.WaitForSingleObject(int(child._handle), 70000)
        forced = wait != 0
        if forced:
            child.terminate()
        child.wait(timeout=10)
    trace = [json.loads(line) for line in events.read_text().splitlines()]
    snapshots = [e for e in trace if 'foregroundPid' in e]
    result = dict(name=name, mode=mode, pid=child.pid, wait=wait, forced=forced,
        exitCode=child.returncode, elapsedSeconds=time.perf_counter()-start,
        firstFrames=sum(e['event'] in ['first_frame', 'first_engine_frame', 'second_engine_frame'] for e in trace),
        enginesDestroyed=sum(e['event'] in ['engine_destroyed', 'first_engine_destroyed'] for e in trace),
        foregroundAlwaysOutsideTest=bool(snapshots) and all(e['foregroundPid']!=child.pid for e in snapshots),
        pluginSha256=hashlib.sha256((folder/'flutter_inappwebview_windows_plugin.dll').read_bytes()).hexdigest(),
        aotSha256=hashlib.sha256((folder/'data/app.so').read_bytes()).hexdigest())
    results.append(result)
    (p/'production-results.json').write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps(result), flush=True)
    assert not forced and child.returncode==0 and result['foregroundAlwaysOutsideTest']
    assert result['firstFrames']==result['enginesDestroyed']==(2 if args else 1)
