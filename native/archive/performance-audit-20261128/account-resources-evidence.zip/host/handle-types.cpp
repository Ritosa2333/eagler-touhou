#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <processsnapshot.h>
#include <iostream>
#include <map>
#include <string>

int wmain(int argc,wchar_t** argv) {
  if(argc<2) return 2;
  const DWORD pid=wcstoul(argv[1],nullptr,10);
  HANDLE process=pid?OpenProcess(PROCESS_QUERY_INFORMATION|PROCESS_VM_READ|PROCESS_DUP_HANDLE,FALSE,pid):GetCurrentProcess();
  if(!process) {std::cout<<"{\"error\":"<<GetLastError()<<"}";return 3;}
  if(pid) {
    wchar_t image[32768];DWORD count=32768;
    if(argc!=3 || !QueryFullProcessImageNameW(process,0,image,&count) || _wcsicmp(image,argv[2])!=0) {
      CloseHandle(process);std::cout<<"{\"error\":\"unexpected target\"}";return 4;
    }
  }
  HPSS snapshot=nullptr;
  auto result=PssCaptureSnapshot(process,static_cast<PSS_CAPTURE_FLAGS>(PSS_CAPTURE_HANDLES|PSS_CAPTURE_HANDLE_BASIC_INFORMATION|PSS_CAPTURE_HANDLE_TYPE_SPECIFIC_INFORMATION),0,&snapshot);
  if(result!=ERROR_SUCCESS) {if(pid)CloseHandle(process);std::cout<<"{\"error\":"<<result<<"}";return 5;}
  HPSSWALK marker=nullptr;
  result=PssWalkMarkerCreate(nullptr,&marker);
  std::map<std::string,unsigned> counts;
  unsigned total=0;
  if(result==ERROR_SUCCESS) {
    PSS_HANDLE_ENTRY entry{};
    while((result=PssWalkSnapshot(snapshot,PSS_WALK_HANDLES,marker,&entry,sizeof(entry)))==ERROR_SUCCESS) {
      std::string type="type-"+std::to_string(entry.ObjectType);
      if(entry.TypeName && entry.TypeNameLength) {
        type.clear();
        // Type labels are ASCII. Do not read or emit object names or contents.
        for(WORD i=0;i<entry.TypeNameLength/sizeof(wchar_t);i++) {
          const auto c=entry.TypeName[i];
          if(c==0) break;
          type+=c>=32 && c<127?static_cast<char>(c):'?';
        }
      }
      counts[type]++;total++;
    }
    PssWalkMarkerFree(marker);
  }
  const auto freeResult=PssFreeSnapshot(GetCurrentProcess(),snapshot);
  if(pid) CloseHandle(process);
  std::cout<<"{\"total\":"<<total<<",\"walkResult\":"<<result<<",\"freeResult\":"<<freeResult<<",\"types\":{";
  bool first=true;
  for(const auto& [type,count]:counts) {if(!first)std::cout<<',';first=false;std::cout<<'"'<<type<<"\":"<<count;}
  std::cout<<"}}";
  return result==ERROR_NO_MORE_ITEMS && freeResult==ERROR_SUCCESS?0:6;
}
