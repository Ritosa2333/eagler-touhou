from pathlib import Path
import os

p = Path(__file__).resolve().parent
source = Path('D:/Temp/native-performance-20261128/account-cancel/account_cancel_probe.dart').read_text(encoding='utf-8')
resize = source[source.index('// The diagnostic host'):source.index('void main()')]
imports = source[:source.index('class _ExternalBrowser')]
imports = '\n'.join(line for line in imports.splitlines() if 'url_launcher' not in line)
body = r'''
void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  final records = <Map<String,Object?>>[];
  final resultPath = Platform.environment['TOUHOU_DESKTOP_TEST_RESULT']!;
  final phasePath = Platform.environment['TOUHOU_MEMORY_PHASE']!;
  Future<void> mark(int cycle,String phase,[Map<String,Object?> extra=const {}]) async {
    final record = {'cycle':cycle,'phase':phase,'utc':DateTime.now().toUtc().toIso8601String(),...extra};
    records.add(record);
    await File(phasePath).writeAsString(jsonEncode(record));
  }
  unawaited(binding.allTestsPassed.future.then((passed) async {
    final temporary = File('$resultPath.tmp');
    await temporary.writeAsString(jsonEncode({'passed':passed,'pid':pid,
      'scope':'Release integration AOT importing production main and canonical Windows DLLs. Repeated public guest login at 390 px, real native Back/Close. No credentials, forced GC or global input.',
      'records':records,'failures':binding.results.map((k,v)=>MapEntry(k,'$v'))}));
    await temporary.rename(resultPath);
  }));
  testWidgets('Repeated live account visits release their native views', (tester) async {
    await app.main([]);
    await tester.pumpAndSettle();
    final window = windows.WindowManager.instance.getCurrent()!;
    _resize(window,const Size(1280,720));
    await tester.pumpAndSettle();
    expect(find.byTooltip(tester.element(find.byType(LibraryPage)).strings.signIn),findsWidgets);
    _resize(window,const Size(390,720));
    await tester.pumpAndSettle();
    final router = GoRouter.of(tester.element(find.byType(LibraryPage)));
    router.push('/game/th06');
    await tester.pumpAndSettle();
    final heading = tester.getRect(find.byType(GameHeading));
    await mark(-1,'baseline');
    await tester.runAsync(()=>Future<void>.delayed(const Duration(seconds:2)));
    final count = int.parse(Platform.environment['TOUHOU_MEMORY_CYCLES'] ?? '16');
    for(var cycle=0;cycle<count;cycle++) {
      await mark(cycle,'opening');
      unawaited(openSiteLink(tester.element(find.byType(GameDetail)),signInFor('/?game=th06')));
      final deadline=DateTime.now().add(const Duration(seconds:30));
      Map<String,dynamic> document={};
      int? texture;
      while(DateTime.now().isBefore(deadline)) {
        await tester.pump();
        final textures=tester.widgetList<Texture>(find.descendant(of:find.byType(AccountWebPage),matching:find.byType(Texture))).toList();
        if(textures.length==1) {
          texture=textures.single.textureId;
          // Pinned plugin command channel only; keep its production callbacks.
          final channel=MethodChannel('com.pichillilorenzo/flutter_inappwebview_$texture');
          final raw=await channel.invokeMethod('evaluateJavascript',{'source':r"""(()=>({path:location.pathname,fields:Array.from(document.querySelectorAll('form input[name]')).filter(e=>e.getBoundingClientRect().width>0).map(e=>e.name),bootReady:!document.getElementById('eaglerPreload'),ready:document.readyState}))()""",'contentWorld':null});
          dynamic value=raw;
          if(value is String) {try{value=jsonDecode(value);}catch(_){}}
          if(value is Map) document=Map<String,dynamic>.from(value);
          if(document['ready']=='complete' && document['bootReady']==true && (document['fields'] as List? ?? []).contains('identity')) break;
        }
        await tester.runAsync(()=>Future<void>.delayed(const Duration(milliseconds:100)));
      }
      expect(document['path'],'/login.html');
      expect(document['fields'],containsAll(['identity','password']));
      expect(document['bootReady'],isTrue);
      await mark(cycle,'loaded',{'texture':texture,'document':document});
      await tester.runAsync(()=>Future<void>.delayed(const Duration(seconds:1)));
      await tester.pump();
      final close=cycle.isOdd;
      await tester.tap(find.descendant(of:find.byType(AccountWebPage),matching:close?find.byIcon(Icons.close):find.byType(BackButton)));
      await tester.pumpAndSettle();
      expect(find.byType(AccountWebPage),findsNothing);
      expect(find.byType(GameDetail).hitTestable(),findsOneWidget);
      expect(tester.getRect(find.byType(GameHeading)),heading);
      await mark(cycle,'closed',{'exit':close?'close':'back','nativeViewRemoved':true});
      await tester.runAsync(()=>Future<void>.delayed(const Duration(milliseconds:1500)));
      await tester.pump();
    }
    await mark(count,'idle');
    await tester.runAsync(()=>Future<void>.delayed(const Duration(seconds:15)));
    await tester.pump();
    await mark(count,'finished');
    await tester.pumpWidget(const SizedBox());
    await tester.pumpAndSettle();
  });
}
'''
(p/'account_memory_probe.dart').write_text(imports+'\n'+resize+body,encoding='utf-8')
preview=p/'preview'
preview.mkdir(exist_ok=True)
base=Path('D:/Temp/native-performance-20261128/shutdown-guard/production')
for file in base.rglob('*'):
    if file.is_file() and file.relative_to(base).as_posix()!='data/app.so':
        destination=preview/file.relative_to(base)
        destination.parent.mkdir(parents=True,exist_ok=True)
        os.link(file,destination)
os.link(Path('D:/Temp/native-performance-20261128/account-return/preview/account-return.exe'),preview/'account-return.exe')
