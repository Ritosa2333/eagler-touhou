@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\Common7\Tools\VsDevCmd.bat" -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
cd /d D:\Temp\native-performance-20261128\account-memory
cl /nologo /O2 /std:c++17 /EHsc /D_WIN32_WINNT=0x0A00 handle-types.cpp /Fe:handle-types.exe /link kernel32.lib
exit /b %errorlevel%
