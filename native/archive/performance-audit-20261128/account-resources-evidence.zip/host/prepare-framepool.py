from pathlib import Path
import hashlib, json, re, shutil

p = Path(__file__).resolve().parent
stage = Path('D:/workspace/eagler/artifacts/.native-room-client-win')
build = stage / 'build/windows/x64'
overlay = build / 'webview_renderer_adapter'
candidate = p / 'framepool'
candidate.mkdir(exist_ok=True)
source = candidate / 'source'
shutil.copytree(overlay, source, dirs_exist_ok=True)
file = source / 'custom_platform_view/texture_bridge.cc'
before = file.read_text()
old = '      capture_session_ = nullptr;\n'
assert before.count(old) == 1
after = before.replace(old, old + '''      auto pool_closable =
        frame_pool_.try_as<ABI::Windows::Foundation::IClosable>();
      assert(pool_closable);
      pool_closable->Close();
      frame_pool_ = nullptr;
      last_frame_ = nullptr;
''')
file.write_text(after, newline='\n')
plugin_build = build / 'plugins/flutter_inappwebview_windows'
tlog = plugin_build / 'flutter_inappwebview_windows_plugin.dir/Release/flutter_.2E7768A0.tlog/CL.command.1.tlog'
lines = tlog.read_text(encoding='utf-16').splitlines()
matches = [lines[i+1] for i, line in enumerate(lines[:-1]) if line.startswith('^') and line.upper().endswith('\\TEXTURE_BRIDGE.CC')]
assert len(matches) == 1
command = matches[0]
command = re.sub(r'/Fo"[^"]*"', '/Fo"' + str(candidate / 'texture_bridge.obj').replace('\\', '/') + '"', command)
command = re.sub(r'/Fd"[^"]*"', '/Fd"' + str(candidate / 'compile.pdb').replace('\\', '/') + '"', command)
command = re.sub(r'(?i)(?:"[^"]*TEXTURE_BRIDGE\.CC"|\S*TEXTURE_BRIDGE\.CC)$', '"' + file.as_posix() + '"', command)
(candidate / 'compile.rsp').write_text(command + '\n')
link = (p.parent / 'shutdown-guard/link.rsp').read_text()
link = link.replace(str(p.parent / 'shutdown-guard'), str(candidate))
# Use the canonical guarded wrapper from the last verified build.
link = link.replace(str(candidate / 'flutter_wrapper_plugin.lib'), str(p.parent / 'shutdown-guard/flutter_wrapper_plugin.lib'))
obj = 'FLUTTER_INAPPWEBVIEW_WINDOWS_PLUGIN.DIR\\RELEASE\\TEXTURE_BRIDGE.OBJ'
assert link.count(obj) == 1
link = link.replace(obj, '"' + str(candidate / 'texture_bridge.obj') + '"')
(candidate / 'link.rsp').write_text(link)
(candidate / 'build.cmd').write_text('''@echo off
call "C:\\Program Files (x86)\\Microsoft Visual Studio\\18\\BuildTools\\Common7\\Tools\\VsDevCmd.bat" -arch=x64 -host_arch=x64
if errorlevel 1 exit /b 1
cd /d "''' + str(plugin_build) + '''"
cl @"''' + str(candidate / 'compile.rsp') + '''"
if errorlevel 1 exit /b 1
link @"''' + str(candidate / 'link.rsp') + '''"
exit /b %errorlevel%
''')
sha = lambda b: hashlib.sha256(b).hexdigest()
(candidate / 'inputs.json').write_text(json.dumps({'baselineDllSha256': sha((p/'preview/flutter_inappwebview_windows_plugin.dll').read_bytes()), 'sourceBefore': sha(before.encode()), 'sourceAfter': sha(after.encode()), 'changed': 'Close capture frame pool and release last frame after capture session closes', 'compile': command}, indent=2) + '\n')
print(json.dumps({'candidate': str(candidate), 'sourceFiles': len(list(source.rglob('*')))}))
