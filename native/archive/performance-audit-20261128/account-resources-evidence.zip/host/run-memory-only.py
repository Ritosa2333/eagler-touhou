from pathlib import Path
import sys, os, json, time, subprocess, hashlib

p=Path(__file__).resolve().parent
sys.path.insert(0,str(p/'vendor'))
import psutil

trial=p/('trial-'+sys.argv[1])
trial.mkdir(exist_ok=False)
phase=trial/'phase.json'
result=trial/'native-result.json'
digest=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
(trial/'input.json').write_text(json.dumps({'psutil':psutil.__version__,'python':sys.version,
    'targetSha256':digest(p/'account_memory_probe.dart'),'testAotSha256':digest(p/'preview/data/app.so'),
    'hostSha256':digest(p/'preview/account-return.exe'),'pluginSha256':digest(p/'preview/flutter_inappwebview_windows_plugin.dll'),
    'cycles':int(sys.argv[2]) if len(sys.argv)>2 else 16,'sampleSeconds':0.5,
    'scope':'Owned process and descendants. Windows private commit and RSS are separate; no memory trimming or forced GC.'},indent=2)+'\n')
with (trial/'runtime.log').open('wb') as log,(trial/'samples.jsonl').open('w') as samples:
    child=subprocess.Popen([str(p/'preview/account-return.exe')],cwd=p/'preview',env=dict(os.environ,
        TOUHOU_GPU_PREFERENCE='high',TOUHOU_DESKTOP_TEST_RESULT=str(result),TOUHOU_PROBE_LOG=str(trial/'events.jsonl'),
        TOUHOU_MEMORY_PHASE=str(phase),TOUHOU_MEMORY_CYCLES=str(int(sys.argv[2]) if len(sys.argv)>2 else 16)),
        stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    process=psutil.Process(child.pid)
    known={}
    started=time.perf_counter()
    lastPhase=None
    print(json.dumps({'pid':child.pid,'scope':'Real WebView cycles in nonactivating owned integration host; descendant sampling only'}),flush=True)
    while child.poll() is None and time.perf_counter()-started<210:
        current={}
        try: current=json.loads(phase.read_text())
        except (FileNotFoundError,json.JSONDecodeError): pass
        key=(current.get('cycle'),current.get('phase'))
        if key!=lastPhase and current.get('phase') in ['closed','idle']:
            print(json.dumps({'cycle':key[0],'phase':key[1]}),flush=True)
        lastPhase=key
        group=[]
        try: descendants=process.children(recursive=True)
        except (psutil.NoSuchProcess,psutil.AccessDenied): descendants=[]
        for item in [process]+descendants:
            try:
                with item.oneshot():
                    creation=item.create_time()
                    memory=item.memory_info()
                    cpu=item.cpu_times()
                    info={'pid':item.pid,'created':creation,'name':item.name(),'parent':item.ppid(),
                        'privateCommit':memory.private,'rss':memory.rss,'handles':item.num_handles(),
                        'cpuSeconds':cpu.user+cpu.system}
                group.append(info)
                if item.pid!=process.pid: known[(item.pid,creation)]=item
            except (psutil.NoSuchProcess,psutil.AccessDenied): pass
        samples.write(json.dumps({'elapsedSeconds':time.perf_counter()-started,'phase':current,'processes':group})+'\n')
        samples.flush()
        time.sleep(0.5)
    forced=child.poll() is None
    if forced: child.terminate()
    child.wait(timeout=15)
    survivorDeadline=time.perf_counter()+8
    while time.perf_counter()<survivorDeadline and any(item.is_running() for item in known.values()): time.sleep(0.5)
    survivors=[{'pid':item.pid,'created':creation} for (_,creation),item in known.items() if item.is_running()]
report={'pid':child.pid,'exitCode':child.returncode,'forced':forced,'elapsedSeconds':time.perf_counter()-started,
    'knownDescendants':len(known),'survivorsAfterEightSeconds':survivors}
if result.exists(): report['testReport']=json.loads(result.read_text())
(trial/'process-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='testReport'}),flush=True)
assert child.returncode==0 and not forced and report.get('testReport',{}).get('passed') is True
