from pathlib import Path
import ctypes,json,subprocess,os,time
p=Path(__file__).resolve().parent;report=p/'native-result.json';assert not report.exists();events=p/'events.jsonl';assert not events.exists()
k=ctypes.WinDLL('kernel32',use_last_error=True);k.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong];k.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)]
with (p/'runtime.log').open('wb') as log:
 child=subprocess.Popen([str(p/'preview/account-return.exe')],cwd=p/'preview',env=dict(os.environ,TOUHOU_GPU_PREFERENCE='high',TOUHOU_DESKTOP_TEST_SCOPE='container',TOUHOU_PROBE_LOG=str(events),TOUHOU_DESKTOP_TEST_RESULT=str(report),TOUHOU_DESKTOP_FRAME_CAPTURE=str(p/'capture')),stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 print(json.dumps({'pid':child.pid,'scope':'Release integration target on canonical native DLLs; own nonactivating window; no external input'}),flush=True)
 started=time.perf_counter();wait=258
 try:
  while time.perf_counter()-started<210:
   wait=k.WaitForSingleObject(int(child._handle),1000)
   if wait==0:break
  code=ctypes.c_ulong();k.GetExitCodeProcess(int(child._handle),ctypes.byref(code));result={'pid':child.pid,'wait':wait,'exitCode':code.value,'elapsedSeconds':time.perf_counter()-started,'forced':False}
 finally:
  if k.WaitForSingleObject(int(child._handle),0)!=0:
   child.terminate();result.update(forced=True,finalWait=k.WaitForSingleObject(int(child._handle),10000))
 if report.exists():result['testReport']=json.loads(report.read_text())
 (p/'process-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
