from pathlib import Path
import ctypes, hashlib, json, subprocess, os, time, sys

p = Path(__file__).resolve().parent
variant = sys.argv[1]
assert variant in ['absent', 'allow', 'absent-repeat', 'final']
trial = p / 'trials' / variant
trial.mkdir(parents=True, exist_ok=False)
(trial / 'capture').mkdir()
report = trial / 'native-result.json'
events = trial / 'events.jsonl'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
(trial / 'input.json').write_text(json.dumps({
    'variant': variant,
    'targetSha256': digest(p / ('compiled-final.dart' if variant == 'final' else 'account_document_probe.dart')),
    'testAotSha256': digest(p / 'preview/data/app.so'),
    'hostSha256': digest(p / 'preview/account-return.exe'),
    'pluginSha256': digest(p / 'preview/flutter_inappwebview_windows_plugin.dll'),
}, indent=2) + '\n')
k = ctypes.WinDLL('kernel32', use_last_error=True)
k.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
k.GetExitCodeProcess.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_ulong)]
with (trial / 'runtime.log').open('wb') as log:
    child = subprocess.Popen([str(p / 'preview/account-return.exe')], cwd=p / 'preview',
        env=dict(os.environ, TOUHOU_GPU_PREFERENCE='high',
            TOUHOU_DESKTOP_TEST_SCOPE='all' if variant == 'final' else 'documents',
            TOUHOU_DOCUMENT_NAVIGATION='allow' if variant == 'allow' else 'absent',
            TOUHOU_PROBE_LOG=str(events), TOUHOU_DESKTOP_TEST_RESULT=str(report),
            TOUHOU_DESKTOP_FRAME_CAPTURE=str(trial / 'capture')),
        stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    print(json.dumps({'pid': child.pid, 'variant': variant, 'scope': 'Owned nonactivating host, no global input'}), flush=True)
    started = time.perf_counter()
    wait = 258
    result = {'pid': child.pid, 'forced': False}
    try:
        while time.perf_counter() - started < 210:
            wait = k.WaitForSingleObject(int(child._handle), 1000)
            if wait == 0:
                break
        code = ctypes.c_ulong()
        k.GetExitCodeProcess(int(child._handle), ctypes.byref(code))
        result.update(wait=wait, exitCode=code.value, elapsedSeconds=time.perf_counter() - started)
    finally:
        if k.WaitForSingleObject(int(child._handle), 0) != 0:
            child.terminate()
            result.update(forced=True, finalWait=k.WaitForSingleObject(int(child._handle), 10000))
    if report.exists():
        result['testReport'] = json.loads(report.read_text())
    (trial / 'process-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
