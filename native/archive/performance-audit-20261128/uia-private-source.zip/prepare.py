from pathlib import Path
import re,os,shutil,json,hashlib
p=Path('D:/Temp/native-performance-20261128/uia-trace');g=p.parent/'gpu-preference';c=p.parent/'client-info';release=p.parent/'shutdown-guard/production'
s=(p/'private-uia.h').read_text();start=s.index('    struct Filter');end=s.index('    auto result = EnableTraceEx2',start)
s=s[:start]+s[end:];s=s.replace(', 0, 0, &enable)',', 0, 0, nullptr)');start=s.index('    if (result == ERROR_INVALID_PARAMETER)');end=s.index('    std::fflush(stdout);',start);s=s[:start]+s[end:];(p/'private-uia.h').write_text(s)
main=(g/'main.cpp').read_text();main='#include "private-uia.h"\n'+main
needle='  flutter::DartProject project(L"data");';assert main.count(needle)==1
main=main.replace(needle,'''  wchar_t etlPath[1024] = {};
  PrivateUiaTrace trace;
  if (GetEnvironmentVariableW(L"TOUHOU_UIA_TRACE_PATH", etlPath, 1024)) trace.Start(etlPath);

'''+needle).replace('GPU preference audit','private UIA trace').replace('  ::CoUninitialize();','  trace.Stop();\n  ::CoUninitialize();');(p/'main.cpp').write_text(main)
s=(g/'window.cpp').read_text();s='#include "client-info-declarations.h"\n'+s
needle='int samples = 0;';s=s.replace(needle,needle+'''
unsigned long long getobjectSeen = 0;
HHOOK ownMessageHook = nullptr;
LRESULT CALLBACK ObserveMessage(int code, WPARAM wp, LPARAM lp) {
  if (code >= 0 && reinterpret_cast<CWPSTRUCT*>(lp)->message == WM_GETOBJECT) ++getobjectSeen;
  return CallNextHookEx(ownMessageHook, code, wp, lp);
}
void Connections() {
  Microsoft::WRL::ComPtr<IUIAutomationClientInfoSource> source;
  HRESULT hr = CoCreateInstance(__uuidof(CUIAutomationClientInfoSource), nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&source));
  SAFEARRAY* clients = nullptr;
  if (SUCCEEDED(hr)) hr = source->GetConnectedClients(&clients);
  std::fprintf(stderr, "UIA_CONNECTIONS hr=%ld getobject=%llu", hr, getobjectSeen);
  if (SUCCEEDED(hr) && clients) {
    LONG lo=0, hi=-1;
    SafeArrayGetLBound(clients, 1, &lo); SafeArrayGetUBound(clients, 1, &hi);
    for (LONG i=lo; i<=hi; ++i) {
      Microsoft::WRL::ComPtr<IUnknown> item;
      Microsoft::WRL::ComPtr<IUIAutomationClientInfo> info;
      if (SUCCEEDED(SafeArrayGetElement(clients, &i, item.GetAddressOf())) && item && SUCCEEDED(item.As(&info))) {
        DWORD pid=0; if (SUCCEEDED(info->get_ProcessId(&pid))) std::fprintf(stderr, " pid=%lu",pid);
      }
    }
    SafeArrayDestroy(clients);
  }
  std::fprintf(stderr,"\\n"); std::fflush(stderr);
}
''')
s=s.replace('  Mark("snapshot",hwnd);','  Mark("snapshot",hwnd);\n  if (samples % 5 == 0) Connections();').replace('++samples==10','++samples==30')
s=s.replace('  RegisterPlugins(flutter_controller_->engine());','  RegisterPlugins(flutter_controller_->engine());\n  ownMessageHook = SetWindowsHookExW(WH_CALLWNDPROC, ObserveMessage, nullptr, GetCurrentThreadId());')
s=s.replace('  Mark("destroy_enter",GetHandle());','  Mark("destroy_enter",GetHandle());\n  if (ownMessageHook) { UnhookWindowsHookEx(ownMessageHook); ownMessageHook=nullptr; }')
(p/'window.cpp').write_text(s);shutil.copyfile(c/'client-info-declarations.h',p/'client-info-declarations.h')
for name in ['main','window']:
 s=(g/(name+'.rsp')).read_text()
 for old,new in [(g/(name+'.cpp'),p/(name+'.cpp')),(g/(name+'.obj'),p/(name+'.obj'))]:
  for before,after in [(str(old),str(new)),(str(old).replace('\\','/'),str(new).replace('\\','/'))]:s=s.replace(before,after)
 s=re.sub(r'/Fd(?:"[^"]*"|\S+)',lambda _: '/Fd"'+str(p/'compile.pdb')+'"',s,flags=re.I);(p/(name+'.rsp')).write_text(s)
link=(g/'link.rsp').read_text()
for old,new in [(g/'main.obj',p/'main.obj'),(g/'window.obj',p/'window.obj'),(g/'preview/gpu-audit.exe',p/'preview/uia-audit.exe')]:
 for before,after in [(str(old),str(new)),(str(old).replace('\\','/'),str(new).replace('\\','/'))]:link=link.replace(before,after)
link+=' ADVAPI32.LIB OLEAUT32.LIB';(p/'link.rsp').write_text(link)
cmd=['@echo off','call "C:\\Program Files (x86)\\Microsoft Visual Studio\\18\\BuildTools\\Common7\\Tools\\VsDevCmd.bat" -arch=x64 -host_arch=x64','if errorlevel 1 exit /b 1','cd /d "D:/workspace/eagler/artifacts/.native-room-client-win/build/windows/x64/runner"']
for name in ['main','window']:cmd+=['cl @"'+str(p/(name+'.rsp'))+'"','if errorlevel 1 exit /b 1']
cmd+=['link @"'+str(p/'link.rsp')+'"','exit /b %errorlevel%'];(p/'build.cmd').write_text('\n'.join(cmd)+'\n')
for f in release.rglob('*'):
 if f.is_file():
  target=p/'preview'/f.relative_to(release);target.parent.mkdir(parents=True,exist_ok=True)
  if not target.exists():os.link(f,target)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();proof={'scope':'In-process-only UIAutomationCore ETW on owned, nonactivating production-AOT diagnostic host. Keyword filter0x10000, 4MiB cap, 16KiB buffers2-4; event ID filtering rejected87 in probe, so no unsupported filter. No product/source/SDK changes.','aotSha256':sha(release/'data/app.so'),'pluginSha256':sha(release/'flutter_inappwebview_windows_plugin.dll'),'sourceSha256':{f.name:sha(f) for f in [p/'main.cpp',p/'window.cpp',p/'private-uia.h',p/'client-info-declarations.h']}}
(p/'source.json').write_text(json.dumps(proof,indent=2)+'\n')
print('Prepared same-AOT private trace diagnostic')
