#include <windows.h>
#include <evntrace.h>
#include <evntcons.h>
#include <tdh.h>
#include <cstdio>
#include <map>
#include <vector>
#include <string>
#pragma comment(lib,"advapi32.lib")
#pragma comment(lib,"tdh.lib")
const GUID provider={0x820a42d8,0x38c4,0x465d,{0xb6,0x4e,0xd7,0xd5,0x6e,0xa1,0xd6,0x12}};
std::map<USHORT,unsigned long long> counts;
unsigned long long total=0,emitted=0,readErrors=0;
std::vector<unsigned char> Property(EVENT_RECORD* event,const wchar_t* name) {
 PROPERTY_DATA_DESCRIPTOR descriptor{};
 descriptor.PropertyName=reinterpret_cast<ULONGLONG>(name);
 descriptor.ArrayIndex=ULONG_MAX;
 ULONG size=0;
 auto status=TdhGetPropertySize(event,0,nullptr,1,&descriptor,&size);
 if(status!=ERROR_SUCCESS || size>4096){++readErrors;return {};}
 std::vector<unsigned char> value(size);
 status=TdhGetProperty(event,0,nullptr,1,&descriptor,size,value.data());
 if(status!=ERROR_SUCCESS){++readErrors;return {};}
 return value;
}
unsigned long long Number(EVENT_RECORD* e,const wchar_t* name) {
 auto value=Property(e,name);unsigned long long number=0;
 if(value.size()<=sizeof(number))memcpy(&number,value.data(),value.size());
 return number;
}
std::string Method(EVENT_RECORD* e) {
 auto value=Property(e,L"MethodName");std::string result;
 for(size_t i=0;i+1<value.size();i+=2){unsigned c=value[i]|(value[i+1]<<8);if(!c)break;if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c==':'||c=='.')result+=static_cast<char>(c);else result+='?';}
 return result;
}
void WINAPI Observe(EVENT_RECORD* event) {
 ++total;
 if(!IsEqualGUID(event->EventHeader.ProviderId,provider))return;
 const auto id=event->EventHeader.EventDescriptor.Id;++counts[id];
 if(id!=509 && id!=510 && id!=519 && id!=520 && id!=544 && id!=545 && id!=546 && id!=547)return;
 ++emitted;
 std::printf("{\"id\":%u,\"version\":%u,\"pid\":%lu,\"tid\":%lu,\"time100ns\":%lld",id,event->EventHeader.EventDescriptor.Version,event->EventHeader.ProcessId,event->EventHeader.ThreadId,event->EventHeader.TimeStamp.QuadPart);
 if(id==519||id==520)std::printf(",\"method\":\"%s\",\"hwnd\":%llu",Method(event).c_str(),Number(event,L"HWND"));
 else {
  std::printf(",\"request\":%llu",Number(event,L"RequestId"));
  if(id==509||id==510)std::printf(",\"method\":\"%s\",\"peer\":%llu,\"duration\":%llu",Method(event).c_str(),Number(event,L"ProcessId"),Number(event,L"Duration"));
  else std::printf(",\"peer\":%llu",Number(event,L"PeerProcessId"));
 }
 std::printf("}\n");
}
int wmain(int argc,wchar_t** argv) {
 if(argc!=2)return 2;
 EVENT_TRACE_LOGFILEW log{};log.LogFileName=argv[1];log.ProcessTraceMode=PROCESS_TRACE_MODE_EVENT_RECORD;log.EventRecordCallback=Observe;
 auto handle=OpenTraceW(&log);if(handle==INVALID_PROCESSTRACE_HANDLE){std::fprintf(stderr,"openStatus=%lu\n",GetLastError());return 3;}
 auto result=ProcessTrace(&handle,1,nullptr,nullptr);auto close=CloseTrace(handle);
 std::fprintf(stderr,"{\"processStatus\":%lu,\"closeStatus\":%lu,\"events\":%llu,\"emitted\":%llu,\"readErrors\":%llu,\"eventsLost\":%lu,\"start100ns\":%lld,\"end100ns\":%lld,\"counts\":{",result,close,total,emitted,readErrors,log.EventsLost,log.LogfileHeader.StartTime.QuadPart,log.LogfileHeader.EndTime.QuadPart);
 bool first=true;for(const auto& item:counts){std::fprintf(stderr,"%s\"%u\":%llu",first?"":",",item.first,item.second);first=false;}std::fprintf(stderr,"}}\n");
 return result==ERROR_SUCCESS&&close==ERROR_SUCCESS?0:4;
}
