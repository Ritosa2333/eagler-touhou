#include <windows.h>
#include <evntrace.h>
#include <evntprov.h>
#include <cstdio>
#include <vector>
#include <string>
#pragma comment(lib,"advapi32.lib")

class PrivateUiaTrace {
 public:
  void Start(const wchar_t* path) {
    storage_.resize(sizeof(EVENT_TRACE_PROPERTIES) + 2048 * sizeof(wchar_t));
    auto* p = Props();
    p->Wnode.BufferSize = static_cast<ULONG>(storage_.size());
    p->Wnode.Flags = WNODE_FLAG_TRACED_GUID;
    p->Wnode.ClientContext = 1;
    p->LogFileMode = EVENT_TRACE_PRIVATE_LOGGER_MODE | EVENT_TRACE_PRIVATE_IN_PROC | EVENT_TRACE_FILE_MODE_SEQUENTIAL;
    p->BufferSize = 16;
    p->MinimumBuffers = 2;
    p->MaximumBuffers = 4;
    p->MaximumFileSize = 4;
    p->FlushTimer = 1;
    p->LoggerNameOffset = sizeof(EVENT_TRACE_PROPERTIES);
    p->LogFileNameOffset = sizeof(EVENT_TRACE_PROPERTIES) + 512 * sizeof(wchar_t);
    name_ = L"TouhouNativePrivateUia-" + std::to_wstring(GetCurrentProcessId());
    wcscpy_s(reinterpret_cast<wchar_t*>(storage_.data() + p->LoggerNameOffset), 512, name_.c_str());
    wcscpy_s(reinterpret_cast<wchar_t*>(storage_.data() + p->LogFileNameOffset), 1536, path);
    start_ = StartTraceW(&handle_, name_.c_str(), p);
    std::printf("{\"event\":\"private_uia_start\",\"pid\":%lu,\"status\":%lu,\"mode\":%lu}\n", GetCurrentProcessId(), start_, p->LogFileMode);
    if (start_ != ERROR_SUCCESS) return;
    const GUID provider = {0x820a42d8,0x38c4,0x465d,{0xb6,0x4e,0xd7,0xd5,0x6e,0xa1,0xd6,0x12}};
    auto result = EnableTraceEx2(handle_, &provider, EVENT_CONTROL_CODE_ENABLE_PROVIDER, TRACE_LEVEL_INFORMATION, 0x10000, 0, 0, nullptr);
    std::printf("{\"event\":\"private_uia_enable\",\"status\":%lu}\n", result);
    std::fflush(stdout);
  }
  void Stop() {
    if (start_ != ERROR_SUCCESS || !handle_) return;
    auto result = ControlTraceW(handle_, name_.c_str(), Props(), EVENT_TRACE_CONTROL_STOP);
    std::printf("{\"event\":\"private_uia_stop\",\"status\":%lu,\"eventsLost\":%lu,\"buffersWritten\":%lu,\"logBuffersLost\":%lu}\n", result, Props()->EventsLost, Props()->BuffersWritten, Props()->LogBuffersLost);
    handle_ = 0;
    std::fflush(stdout);
  }
  ~PrivateUiaTrace() { Stop(); }
 private:
  EVENT_TRACE_PROPERTIES* Props() { return reinterpret_cast<EVENT_TRACE_PROPERTIES*>(storage_.data()); }
  std::vector<unsigned char> storage_;
  TRACEHANDLE handle_ = 0;
  ULONG start_ = ERROR_INVALID_HANDLE;
  std::wstring name_;
};
