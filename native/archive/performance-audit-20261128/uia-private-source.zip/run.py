from pathlib import Path
import subprocess,ctypes,os,time,json,sys
p=Path(__file__).resolve().parent;mode=sys.argv[1];assert mode in ['passive','control'];events=p/(mode+'-events.jsonl');assert not events.exists()
k=ctypes.WinDLL('kernel32',use_last_error=True);k.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong];k.GetExitCodeProcess.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_ulong)]
with (p/(mode+'-stdout.log')).open('wb') as log:
 process=subprocess.Popen([str(p/'preview/uia-audit.exe')],cwd=p/'preview',env=dict(os.environ,TOUHOU_GPU_PREFERENCE='high',TOUHOU_PROBE_LOG=str(events),TOUHOU_UIA_TRACE_PATH=str(p/(mode+'.etl'))),stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 print(json.dumps({'mode':mode,'pid':process.pid}),flush=True)
 wait=k.WaitForSingleObject(int(process._handle),60000);code=ctypes.c_ulong();k.GetExitCodeProcess(int(process._handle),ctypes.byref(code));result={'mode':mode,'pid':process.pid,'wait':wait,'exitCode':code.value,'forced':False}
 if wait!=0:process.terminate();result.update(forced=True,finalWait=k.WaitForSingleObject(int(process._handle),10000))
 (p/(mode+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
