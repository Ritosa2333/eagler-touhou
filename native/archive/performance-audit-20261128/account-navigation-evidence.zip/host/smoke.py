from pathlib import Path
import ctypes, hashlib, json, os, subprocess, time

p = Path(__file__).resolve().parent
runtime = Path('D:/Temp/native-performance-20261128/shutdown-guard/production')
folder = p/'ordinary-smoke'
folder.mkdir(exist_ok=False)
for file in runtime.rglob('*'):
    if file.is_file():
        destination = folder/file.relative_to(runtime)
        destination.parent.mkdir(parents=True,exist_ok=True)
        os.link(file,destination)
os.link(p/'preview/account-return.exe',folder/'account-return.exe')
marker = p/'smoke-close-marker.json'
marker.write_text('{"scope":"Startup smoke close marker, not an integration assertion"}\n')
events = p/'smoke-events.jsonl'
with (p/'smoke-runtime.log').open('wb') as log:
    child = subprocess.Popen([str(folder/'account-return.exe')],cwd=folder,
        env=dict(os.environ,TOUHOU_GPU_PREFERENCE='high',TOUHOU_PROBE_LOG=str(events),TOUHOU_DESKTOP_TEST_RESULT=str(marker)),
        stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
    print(json.dumps({'pid':child.pid,'scope':'Ordinary main AOT startup and normal close, diagnostic no-activation host'}),flush=True)
    kernel = ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_ulong]
    started=time.perf_counter()
    status=kernel.WaitForSingleObject(int(child._handle),45000)
    forced=status!=0
    if forced:
        child.terminate()
    child.wait(timeout=10)
trace=[json.loads(line) for line in events.read_text().splitlines()]
result={'scope':'Ordinary main.dart AOT startup and close only; own nonactivating diagnostic host; no manual navigation or foreground FPS claim',
    'pid':child.pid,'wait':status,'exitCode':child.returncode,'forced':forced,'elapsedSeconds':time.perf_counter()-started,
    'firstFrame':any(e['event']=='first_frame' for e in trace),'engineDestroyed':any(e['event']=='engine_destroyed' for e in trace),
    'foregroundAlwaysOutsideTest':all(e.get('foregroundPid')!=child.pid for e in trace),
    'aotSha256':hashlib.sha256((folder/'data/app.so').read_bytes()).hexdigest()}
(p/'smoke-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
assert result['exitCode']==0 and not forced and result['firstFrame'] and result['engineDestroyed'] and result['foregroundAlwaysOutsideTest']
