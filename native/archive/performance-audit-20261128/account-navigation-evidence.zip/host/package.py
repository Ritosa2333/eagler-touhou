from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, zipfile

p = Path(__file__).resolve().parent
out = Path('D:/workspace/eagler/artifacts/native-launcher-85941f0d56')
runtime = Path('D:/Temp/native-performance-20261128/shutdown-guard/production')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
target = out/'touhouonline-windows-preview.zip'
oldSha = sha(target)
assert oldSha == '0bbac79a4805c02ec258e08d4a73ae52c58920808a82b157b9c9b16db6146e37'
aot = p/'ordinary-bundle/windows/app.so'
assert aot.is_file() and sha(aot) != '7e58aabca9ef35fd1907fe0b7bfcbccd636d7ef1f97bd77de20e9b331fc3cf95'
candidate = p/'windows-candidate.zip'
assert not candidate.exists()
files = {}
assets = 0
with zipfile.ZipFile(target) as before, zipfile.ZipFile(candidate,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as after:
    for item in before.infolist():
        if item.is_dir():
            continue
        data = aot.read_bytes() if item.filename == 'data/app.so' else before.read(item.filename)
        if item.filename.startswith('data/flutter_assets/'):
            new = p/'ordinary-bundle/flutter_assets'/item.filename.removeprefix('data/flutter_assets/')
            assert new.read_bytes() == data,item.filename
            assets += 1
        after.writestr(item, data)
        files[item.filename] = hashlib.sha256(data).hexdigest()
with zipfile.ZipFile(candidate) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(files)
    for name,digest in files.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == digest,name
assert assets == 353
assert all(sha(runtime/name)==digest for name,digest in files.items() if name!='data/app.so')
temporary = runtime/'data/app.so.next'
shutil.copy2(aot,temporary)
os.replace(temporary,runtime/'data/app.so')
os.replace(target,out/'touhouonline-windows-preview.previous.zip')
os.replace(candidate,target)
result = {'checkedAtUtc':datetime.now(timezone.utc).isoformat(),'scope':'Official ordinary lib/main.dart Release reassembly; only Dart AOT changed; all 353 assets and native binaries unchanged; no deployment',
    'oldPackageSha256':oldSha,'package':target.name,'sha256':sha(target),'bytes':target.stat().st_size,'aotSha256':sha(aot),'changedRuntimeFiles':['data/app.so'],'unchangedAssets':assets,'files':files}
(p/'ordinary-package.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'}))
