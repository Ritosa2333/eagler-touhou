import 'dart:async';
import 'dart:convert';
import 'dart:ffi' as ffi;
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart' as web;
import 'package:integration_test/integration_test.dart';
import 'package:go_router/go_router.dart';
import 'package:material_ui/material_ui.dart';
import 'package:window_manager/window_manager.dart' as windows;
import 'package:url_launcher_platform_interface/url_launcher_platform_interface.dart';
import 'package:url_launcher_platform_interface/link.dart';
import 'package:touhouonline/account_web_page.dart';
import 'package:touhouonline/game_detail.dart';
import 'package:touhouonline/library.dart';
import 'package:touhouonline/l10n/strings.dart';
import 'package:touhouonline/main.dart' as app;
import 'package:touhouonline/site_documents.dart';

class _ExternalBrowser extends UrlLauncherPlatform {
  final requests = <String>[];
  @override
  LinkDelegate? get linkDelegate => null;
  @override
  Future<bool> launchUrl(String url, LaunchOptions options) async {
    requests.add(url);
    return true;
  }
}

// The diagnostic host supplies only its own PID and HWND. Ordinary CI uses
// window_manager; the isolated host resizes with the Win32 no-activation flag.
void _resize(windows.Window window, Size size) {
  final target = Platform.environment['TOUHOU_DESKTOP_TEST_WINDOW'];
  if (target == null) {
    window.setSize(size.toNative(), false);
    return;
  }
  final parts = target.split(':');
  if (parts.length != 2 || int.tryParse(parts[0]) != pid) {
    throw StateError('Desktop test window must belong to this process');
  }
  final hwnd = int.parse(parts[1]);
  final user32 = ffi.DynamicLibrary.open('user32.dll');
  final dpi = user32
      .lookupFunction<ffi.Uint32 Function(ffi.IntPtr), int Function(int)>(
        'GetDpiForWindow',
      )(hwnd);
  if (dpi == 0) throw StateError('Desktop test HWND is unavailable');
  final setWindowPos = user32
      .lookupFunction<
        ffi.Int32 Function(
          ffi.IntPtr,
          ffi.IntPtr,
          ffi.Int32,
          ffi.Int32,
          ffi.Int32,
          ffi.Int32,
          ffi.Uint32,
        ),
        int Function(int, int, int, int, int, int, int)
      >('SetWindowPos');
  const swpNoMove = 0x0002;
  const swpNoZOrder = 0x0004;
  const swpNoActivate = 0x0010;
  if (setWindowPos(
        hwnd,
        0,
        0,
        0,
        (size.width * dpi / 96).round(),
        (size.height * dpi / 96).round(),
        swpNoMove | swpNoZOrder | swpNoActivate,
      ) ==
      0) {
    throw StateError('Desktop test resize failed');
  }
}

void main() {
  final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  final observations = <Map<String, Object?>>[];
  final resultPath = Platform.environment['TOUHOU_DESKTOP_TEST_RESULT']!;
  unawaited(
    binding.allTestsPassed.future.then((passed) async {
      final temporary = File('$resultPath.tmp');
      await temporary.writeAsString(
        jsonEncode({
          'passed': passed,
          'pid': pid,
          'scope': 'Live production account widget and Windows engine; OS browser launch intercepted by platform test adapter; no credentials or global input',
          'observations': observations,
          'failures': binding.results.map((k, v) => MapEntry(k, '$v')),
        }),
      );
      await temporary.rename(resultPath);
    }),
  );
  testWidgets('Live account survives intercepted external navigation', (
    tester,
  ) async {
    await app.main([]);
    await tester.pumpAndSettle();
    final originalBrowser = UrlLauncherPlatform.instance;
    final browser = _ExternalBrowser();
    UrlLauncherPlatform.instance = browser;
    addTearDown(() => UrlLauncherPlatform.instance = originalBrowser);
    final window = windows.WindowManager.instance.getCurrent()!;
    _resize(window, const Size(1280, 720));
    await tester.pumpAndSettle();
    final router = GoRouter.of(tester.element(find.byType(LibraryPage)));
    expect(
      find.byTooltip(tester.element(find.byType(LibraryPage)).strings.signIn),
      findsWidgets,
    );
    _resize(window, const Size(390, 720));
    await tester.pumpAndSettle();
    router.push('/game/th06');
    await tester.pumpAndSettle();
    unawaited(
      openSiteLink(
        tester.element(find.byType(GameDetail)),
        signInFor('/?game=th06'),
      ),
    );
    final deadline = DateTime.now().add(const Duration(seconds: 30));
    MethodChannel? channel;
    Future<dynamic> evaluate(String source) async {
      final result = await channel!.invokeMethod('evaluateJavascript', {
        'source': source,
        'contentWorld': null,
      });
      if (result is String) {
        try {
          return jsonDecode(result);
        } catch (_) {}
      }
      return result;
    }

    // Use the pinned plugin's existing command channel without constructing a
    // second controller or replacing the production navigation/event handlers.
    Map<String, dynamic> before = {};
    while (DateTime.now().isBefore(deadline)) {
      await tester.pump();
      final textures = tester
          .widgetList<Texture>(
            find.descendant(
              of: find.byType(AccountWebPage),
              matching: find.byType(Texture),
            ),
          )
          .toList();
      if (textures.length == 1) {
        channel ??= MethodChannel(
          'com.pichillilorenzo/flutter_inappwebview_${textures.single.textureId}',
        );
        final result = await evaluate(
          """(()=>({path:location.pathname,fields:Array.from(document.querySelectorAll('form input[name]')).map(e=>e.name),bootReady:!document.getElementById('eaglerPreload'),title:document.title}))()""",
        );
        if (result is Map) before = Map<String, dynamic>.from(result);
        if ((before['fields'] as List? ?? []).contains('identity') &&
            before['bootReady'] == true)
          break;
      }
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 100)),
      );
    }
    observations.add({'event': 'before', ...before});
    expect(before['path'], '/login.html');
    expect(before['fields'], contains('identity'));
    final state = tester.state(find.byType(web.InAppWebView));
    await evaluate(
      """(()=>{const link=document.createElement('a');link.href='https://example.com/navigation-check';document.body.append(link);link.click();return true;})()""",
    );
    final externalDeadline = DateTime.now().add(const Duration(seconds: 10));
    while (browser.requests.isEmpty &&
        DateTime.now().isBefore(externalDeadline)) {
      await tester.pump();
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 100)),
      );
    }
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(seconds: 1)),
    );
    await tester.pump();
    final present = find.byType(web.InAppWebView).evaluate().isNotEmpty;
    final retry = find
        .text(
          tester.element(find.byType(AccountWebPage)).strings.cannotOpenLink,
        )
        .evaluate()
        .isNotEmpty;
    observations.add({
      'event': 'afterCancel',
      'externalRequests': browser.requests,
      'webViewPresent': present,
      'retryVisible': retry,
      'sameState':
          present &&
          identical(state, tester.state(find.byType(web.InAppWebView))),
    });
    expect(browser.requests, ['https://example.com/navigation-check']);
    expect(
      present,
      isTrue,
      reason: 'Intercepted external navigation must preserve the loaded account form',
    );
    expect(retry, isFalse);
    observations.add({
      'event': 'afterDocument',
      'value': await evaluate(
        "({path:location.pathname,fields:Array.from(document.querySelectorAll('form input[name]')).map(e=>e.name)})",
      ),
    });
    await tester.tap(
      find.descendant(
        of: find.byType(AccountWebPage),
        matching: find.byIcon(Icons.close),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.byType(GameDetail).hitTestable(), findsOneWidget);
    await tester.pumpWidget(const SizedBox());
    await tester.pumpAndSettle();
  });
}
